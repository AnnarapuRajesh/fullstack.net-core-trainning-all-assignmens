create database test1;
use test1;
CREATE TABLE Employeepatent(
Empid Int IDENTITY (1, 1) NOT NULL Primary key,
EmpNumber nvarchar(50) NOT NULL,
EmpFirstName varchar(150) NOT NULL,
EmpLastName varchar(150) NULL,
EmpEmail varchar(150) NULL,
Managerid int NULL,
Departmentid INT
)
CREATE TABLE [Departmentchild]([Departmenttid] [int] IDENTITY (1, 1) NOT NULL primary key,[DepartmentName] [nvarchar](255) NOT NULL)


insert into Employeepatent(EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)values('A001','Samir','Singh','samir@abc.com',2,2)
insert into Employeepatent(EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)values('A002','Amit','Kumar','amit@abc.com',1,1)
insert into Employeepatent (EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)values('A003','Neha','Sharma','neha@abc.com',1,2)
insert into Employeepatent (EmpNumber,EmpFirstName,EmpLastName,EmpEmail,Managerid,Departmentid)values('A004','Vivek','Kumar','vivek@abc.com',1,NULL)


    insert into [Departmentchild](DepartmentName)
values('Accounts')
insert into [Departmentchild](DepartmentName)
values('Admin')
insert into [Departmentchild](DepartmentName)
values('HR')
insert into [Departmentchild](DepartmentName)
values('Technology')

select * from Employeepatent;
select * from Departmentchild;
select EmpFirstName,EmpLastName,DepartmentName from Employeepatent left outer join Departmentchild on Employeepatent.Departmentid = Departmentchild.Departmenttid;
select EmpFirstName,EmpLastName,DepartmentName from Employeepatent right outer join Departmentchild on Employeepatent.Departmentid = Departmentchild.Departmenttid;
select EmpFirstName,EmpLastName,DepartmentName from Employeepatent full outer join Departmentchild on Employeepatent.Departmentid = Departmentchild.Departmenttid;