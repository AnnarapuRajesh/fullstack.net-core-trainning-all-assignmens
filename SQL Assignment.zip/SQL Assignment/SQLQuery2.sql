CREATE DATABASE Students;
USE Students;
CREATE TABLE StudentsInfo
(
StudentID int,StudentName varchar(8000),
ParentName varchar(8000),PhoneNumber bigint,AddressofStudent varchar(8000),City varchar(8000),Country varchar(8000)
);
DROP TABLE StudentsInfo;
DROP DATABASE Students;
CREATE DATABASE STudents1;
DROP DATABASE STudents

ALTER TABLE StudentsInfo ADD BlooodGroup VARCHAR(8000);
ALTER TABLE StudentsInfo DROP COLUMN BlooodGroup;
ALTER TABLE StudentsInfo ADD DOB DATE;
ALTER TABLE StudentsInfo DROP COLUMN DOB;
INSERT INTO StudentsInfo VALUES ('07','vishal','mishra','6165154555','nice road 15','pune','india');
TRUNCATE TABLE StudentsInfo;
sp_rename 'StudentsInfo','InfoStudents';
