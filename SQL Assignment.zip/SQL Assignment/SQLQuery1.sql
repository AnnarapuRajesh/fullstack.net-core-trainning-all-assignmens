create database Assesment1
use Assesment1
CREATE  TABLE Customers (
  ID INT primary key ,
  FirstName nvarchar(40),
  LastName nvarchar(40),
  City nvarchar(40),
  Country nvarchar(40),
  PhoneNo nvarchar(40) );
  CREATE Index IX_CustomersName_FirstName on Customers(FirstName ASC)
  alter table Customers
alter column FirstName nvarchar(40) not null;
drop VIEW CustomersName;
insert into Customers(ID,FirstName,LastName,City,Country,PhoneNo) values
(1,'rajesh','annarapu','warangal','india',7719057517),
(2,'preetham','burra','kazipet','india',8595455465),
(4,'rakesh','dasari','warangal','india',8919373856),
(3,'sreekar','janga','hnk','india',8919373866),
(5,'pavan','barupati','narsampet','india',8919373856);
select * from Customers;
select Country from Customers where FirstName like 'A%' or FirstName like 'i%';


CREATE  TABLE Orders (
  ID INT primary key ,
  customer_id INT FOREIGN KEY REFERENCES Customers (ID),
  OrderDate datetime not null,
  OrderNumber nvarchar(10),
  TotalAmount decimal(12,2));
  
 
  select * from Orders;

  CREATE Index IX_Orders_customer_id on Orders(customer_id);
  CREATE Index IX_Orders_OrderDate on Orders(OrderDate);
  insert into Orders(ID,customer_id,OrderDate,OrderNumber,TotalAmount) values
  (1,44,2022-02-15,'484455',15.2),
  (2,23,2019-01-26,'454445',45.2),
  (3,47,2010-06-08,'485548',78.1),
  (4,77,2018-11-25,'118851',44.2),
  (5,47,2010-04-17,'475869',154.2),
  (6,59,2014-08-17,'415263',478.25);
  
  use Students;
  create table newstudents(id int not null,Studentname nvarchar);
  insert into Students(id,Studentname) values ('rajesh');
  use Assesment1

  CREATE  TABLE Products (
  ID INT primary key,
  ProductName nvarchar(50),
  UnitPrice decimal(12,2),
  Package nvarchar(20),
  IsDiscontuned bit);
  
  CREATE  TABLE OrderItems (
  ID INT primary key ,
  OrderID INT NOT NULL FOREIGN KEY REFERENCES Orders (ID),
  ProductID INT NOT NULL FOREIGN KEY REFERENCES Products (ID),
  UnitPrice decimal(12,2),
  Quantity int);
  
  SELECT FirstName FROM Customers
WHERE FirstName LIKE '___I%';
select FirstName+ +LastName as FullName From Customers;
select * from Customers where Country = 'germany';